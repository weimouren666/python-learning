# Git 最小生存指南 —— 写给学习仓库的主人

> 目标：30 分钟后，你能独立完成"每周把学习代码推上 GitHub"。
> 只学必须的，不学暂时用不上的。

## 0. 为什么这事值得（30 秒）

- git 会给每一次提交拍一张"快照"，一年后 `git log` 就是你 14 周的完整成长日志
- 这是你们专业大二大三的必修工具（数据结构、大数据框架全靠它协作），现在用最安全的方式练手
- 简历上"用 git 管理学习代码 + commit 历史清晰"是真实加分项

## 1. 一次性安装与配置（10 分钟，只做一次）

**装 Git**：去 [git-scm.com](https://git-scm.com/download/win) 下载 Windows 版，安装时一路默认（默认选项已经很好）。

**配置身份**（告诉 GitHub 是谁在提交）。打开 **Git Bash**（装完 git 开始菜单里就有），逐行执行：

```bash
git config --global user.name "你的名字(拼音或网名)"
git config --global user.email "你注册GitHub用的邮箱"
```

⚠️ 邮箱必须和你 GitHub 账号的邮箱一致，否则贡献统计不显示在你头像下。

## 2. 首次把文件放进仓库（5 分钟，只做一次）

最省事的方式是 **clone（克隆）**—— 把 GitHub 上的空仓库拉到本地：

```bash
cd ~/Desktop                # 你想放代码的地方
git clone https://github.com/你的用户名/仓库名.git
cd 仓库名                   # 进入仓库目录
```

然后把下载的《Python 学习档案 zip》解压，把里面的 `README.md`、`Git最小生存指南.md`、`作业代码/`、`lessons/`、`experiments/` 全部**复制进这个仓库文件夹**。

## 3. 每周三板斧（课后 5 分钟，重复使用）

在仓库目录里打开 Git Bash（或右键 → Open Git Bash here），按顺序：

```bash
git add .                                       # ① 把所有新文件/改动放进"待提交区"
git commit -m "第2周：分支与循环 + 猜数字游戏"     # ② 拍快照，写一句说明
git push                                        # ③ 推送到 GitHub
```

第一次 push 会弹出 GitHub 登录窗口（浏览器授权），登录一次以后就不用了。

**记住这个节奏：改了东西 → add → commit → push。就这么简单。**

## 4. commit message 怎么写（这是你的学习日志）

公式：**第 N 周：主题 + 这次做了什么**

```bash
git commit -m "第1周：变量与数据类型，完成BMI计算器作业"      # ✅ 好
git commit -m "第1周实战：个人信息卡片生成器，修复缩进问题"    # ✅ 好
git commit -m "update"                                     # ❌ 半年后你自己都不知道干了啥
```

## 5. 常见事故与自救

| 状况 | 处理 |
|---|---|
| 忘了这次改了啥 | `git status` —— 随时敲，永远无害 |
| push 被拒绝（rejected） | 先 `git pull` 把远端拉下来，再 `git push` |
| commit 写错字了 | 还没 push 的话：`git commit --amend -m "新消息"` |
| 想看完整历史 | `git log --oneline` |
| 什么都不想记了 | 就记三板斧，其他的遇到再说 |

## 6. 可选：让沙箱（AI 老师）直接推

如果某周你不想手动操作，可以把"推 GitHub"这件事交给我做。配置方法：

1. GitHub 网页 → 右上角头像 → **Settings** → 最底部 **Developer settings**
2. **Personal access tokens → Fine-grained tokens → Generate new token**
3. 设置三项：
   - **Repository access**：Only select repositories → 只勾你的学习仓库
   - **Permissions → Contents**：Read and write（其他全部不勾）
   - **Expiration**：90 天（到期重新生成一个就行）
4. 把 token 和仓库地址发我，我配置好后每次课后就能直接 push

**安全三原则**：只授权这一个仓库（别人拿到也只碰得到学习笔记）· 90 天过期 · 随时可以回 GitHub 把它撤销。token 泄露的最坏结果 = 你的学习笔记被改，损失为零，所以放心用，但习惯要养对。
